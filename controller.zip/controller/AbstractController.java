package controller;

public interface AbstractController {
    void addUser(ClientNode deviceNode, ClientNode clientNode);
}
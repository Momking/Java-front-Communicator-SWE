package controller;

public record ClientNode(String hostName, int port) {
}